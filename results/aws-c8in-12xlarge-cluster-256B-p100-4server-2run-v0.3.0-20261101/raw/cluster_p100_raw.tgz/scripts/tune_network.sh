#!/usr/bin/env bash
# Network tuning of a host with an ENA NIC, as applied to all five machines of this run (see the repository
# README). Run it as the login user (it uses sudo), after harness/tune_server.sh.
set -u
I=$(ip route get 1.1.1.1 | sed -n 's/.* dev \([^ ]*\).*/\1/p')
N=$(nproc)
# RPS and RFS over every CPU
MASK=$(python3 - <<PY
n=$N
m=(1<<n)-1
h="%0*x"%(((n+3)//4),m)
h=h.zfill(((len(h)+7)//8)*8)
print(",".join(h[i:i+8] for i in range(0,len(h),8)))
PY
)
sudo sysctl -w net.core.rps_sock_flow_entries=1048576 > /dev/null
Q=$(ls -d /sys/class/net/$I/queues/rx-* | wc -l)
for q in /sys/class/net/$I/queues/rx-*; do
  echo "$MASK" | sudo tee $q/rps_cpus > /dev/null
  echo $((1048576 / Q)) | sudo tee $q/rps_flow_cnt > /dev/null
done
# receive ring at its maximum, larger softirq budget
sudo ethtool -G "$I" rx 8192 2>&1 | tail -1
sudo sysctl -w net.core.netdev_budget=4800 net.core.netdev_budget_usecs=16000 > /dev/null
# keep the listen backlogs across a reboot
sudo tee /etc/sysctl.d/99-hotkv-bench.conf > /dev/null <<EOT
fs.file-max=2097152
net.core.somaxconn=65535
net.ipv4.tcp_max_syn_backlog=65535
net.core.netdev_max_backlog=65535
vm.overcommit_memory=1
EOT
sudo sysctl --system > /dev/null 2>&1 || true

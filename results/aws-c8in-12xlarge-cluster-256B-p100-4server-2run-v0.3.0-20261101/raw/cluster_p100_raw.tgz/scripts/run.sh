#!/usr/bin/env bash
# The command sequence of this run: the four servers one after another on three server hosts (NODES), driven by the
# machine this script runs on plus one more load generator (EXTRA_CLIENTS, host:processes). Copy
# harness/cluster_bench_sweep.sh to /tmp on the main load generator first. The addresses are the private ones of the run.
# Each server's results land in $HOME/results/<server>; they are the folders under data/.
export NODES="172.31.44.55 172.31.36.139 172.31.34.226" HOTKV_BIN=/opt/hotkv/build/pf/src/hotkv DRAGONFLY_BIN=$HOME/bench/opt/dragonfly
export RUNS=2 TEST_TIME=15 PIPELINES=100 COMMANDS="GET SET SETNX INCR SADD RPUSH HSET LPUSH APPEND" SERVER_CPUS=0-39 EXTRA_CLIENTS="172.31.47.233:4"
OUT=$HOME/results/hotkv EXTRA_NODE_CONF_HOTKV="pipeline-prefetch yes" SERVERS=hotkv KS=1 THREADS_PER_NODE=40 bash /tmp/cluster_bench_sweep.sh
OUT=$HOME/results/redis SERVERS=redis KS=40 THREADS_PER_NODE=1 bash /tmp/cluster_bench_sweep.sh
OUT=$HOME/results/valkey SERVERS=valkey KS=40 THREADS_PER_NODE=1 bash /tmp/cluster_bench_sweep.sh
OUT=$HOME/results/dragonfly SERVERS=dragonfly KS=1 THREADS_PER_NODE=40 bash /tmp/cluster_bench_sweep.sh

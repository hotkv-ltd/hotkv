#!/usr/bin/env python3
"""Turn data/<server>/results.csv into the self-contained RESULTS.html of this run.

    python3 scripts/render_report.py

Reads data/hotkv, data/redis, data/valkey and data/dragonfly (one results.csv each), computes the median of the runs of every
command, flags the figures where the main load generator ran above 85 percent CPU, and writes RESULTS.html next to README.md.
"""
import csv
import html
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SERVERS = [("hotkv", "HotKV", "0.3.0"), ("redis", "Redis", "8.10.3"), ("valkey", "Valkey", "9.1.3"), ("dragonfly", "Dragonfly", "2.0.2")]
COLORS = {"hotkv": "#ea580c", "redis": "#64748b", "valkey": "#94a3b8", "dragonfly": "#7c3aed"}
CLIENT_BOUND_PCT = 85

data = {}  # server -> command -> list of run rows
for key, _, _ in SERVERS:
    for row in csv.DictReader(open(ROOT / "data" / key / "results.csv", encoding="utf-8")):
        data.setdefault(key, {}).setdefault(row["command"], []).append(row)
commands = list(data["hotkv"])


def median(key, cmd):
    return statistics.median(float(r["ops_per_sec"]) for r in data[key][cmd])


def client_bound(key, cmd):
    return min(int(r["driver_cpu_pct"]) for r in data[key][cmd]) > CLIENT_BOUND_PCT


def mops(n):
    return f"{n / 1e6:.1f}"


esc = html.escape
rows_chart = []
for cmd in commands:
    top = max(median(k, cmd) for k, _, _ in SERVERS)
    bars = []
    for key, name, _ in SERVERS:
        v = median(key, cmd)
        lead = v == top
        flag = "†" if client_bound(key, cmd) else ""
        bars.append(
            f'<div class="bar"><span class="who">{name}</span><span class="track"><i style="width:{v / top * 100:.1f}%;background:{COLORS[key]}"></i></span>'
            f'<span class="val{" lead" if lead else ""}">{"★ " if lead else ""}{mops(v)}M{flag}</span></div>'
        )
    rows_chart.append(f'<div class="row"><div class="cmd">{cmd}</div><div class="bars">{"".join(bars)}</div></div>')

table = []
for cmd in commands:
    cells = "".join(f"<td>{median(k, cmd):,.0f}{'†' if client_bound(k, cmd) else ''}</td>" for k, _, _ in SERVERS)
    ratios = "".join(f"<td>{median('hotkv', cmd) / median(k, cmd):.2f}x</td>" for k in ("redis", "valkey", "dragonfly"))
    table.append(f"<tr><th scope='row'>{cmd}</th>{cells}{ratios}</tr>")

runs = []
for key, name, _ in SERVERS:
    for cmd in commands:
        for r in data[key][cmd]:
            runs.append(
                f"<tr><td>{name}</td><td>{cmd}</td><td>{r['run']}</td><td>{int(r['ops_per_sec']):,}</td><td>{r['hit_ratio']}</td>"
                f"<td>{r['driver_cpu_pct']}</td><td>{esc(r['note'].replace('extra_client_cpu=', ''))}</td><td>{esc(r['node_cpu_pct'])}</td></tr>"
            )

legend = "".join(f'<span><i style="background:{COLORS[k]}"></i>{n} {v}</span>' for k, n, v in SERVERS)
page = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Three-node cluster benchmark, 2026-11-01</title>
<style>
:root{{--bg:#faf9f7;--card:#fff;--ink:#0f172a;--muted:#475569;--line:#e2e8f0}}
@media(prefers-color-scheme:dark){{:root{{--bg:#0f1427;--card:#1b2240;--ink:#eef1f8;--muted:#9aa4c4;--line:#2d3761}}}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--ink);font:16px/1.6 system-ui,Segoe UI,Arial,sans-serif}}
main{{max-width:1040px;margin:0 auto;padding:40px 20px 80px}}h1{{font-size:32px;line-height:1.2;margin:0 0 8px}}h2{{margin:44px 0 12px;font-size:22px}}
p,li{{color:var(--muted)}}.card{{background:var(--card);border:1px solid var(--line);border-radius:14px;overflow:hidden}}
.legend{{display:flex;flex-wrap:wrap;gap:6px 20px;margin:16px 0;font-size:14px}}.legend i{{display:inline-block;width:11px;height:11px;border-radius:3px;margin-right:6px}}
.row{{display:grid;grid-template-columns:90px 1fr;gap:12px;padding:12px 18px;border-top:1px solid var(--line)}}.row:first-child{{border-top:0}}
.cmd{{font:600 14px ui-monospace,Consolas,monospace}}.bar{{display:grid;grid-template-columns:78px 1fr 84px;gap:10px;align-items:center;font-size:12px;color:var(--muted)}}
.track{{height:12px;background:var(--line);border-radius:3px;overflow:hidden}}.track i{{display:block;height:100%}}.val{{text-align:right;font:12px ui-monospace,Consolas,monospace}}.lead{{color:var(--ink);font-weight:700}}
table{{width:100%;border-collapse:collapse;font-size:14px}}th,td{{padding:9px 12px;text-align:right;border-top:1px solid var(--line);white-space:nowrap}}th:first-child,td:first-child{{text-align:left}}thead th{{background:var(--line);font-size:12px;text-transform:uppercase;letter-spacing:.04em}}
.scroll{{overflow-x:auto}}code{{font:13px ui-monospace,Consolas,monospace}}@media(max-width:640px){{.bar{{grid-template-columns:70px 1fr 78px}}.row{{grid-template-columns:1fr}}}}
</style></head><body><main>
<h1>Three-node cluster benchmark</h1>
<p>HotKV, Redis, Valkey and Dragonfly as three-node clusters on AWS, measured on 2026-11-01. Millions of operations per second, median of 2 runs.
† marks a figure where the main load generator ran above {CLIENT_BOUND_PCT} percent CPU, so it is a lower bound. ★ marks the highest value of a command.</p>
<div class="legend">{legend}</div>
<div class="card">{"".join(rows_chart)}</div>

<h2>Exact figures</h2>
<div class="card scroll"><table><thead><tr><th>Command</th>{"".join(f"<th>{n}</th>" for _, n, _ in SERVERS)}<th>HotKV vs Redis</th><th>HotKV vs Valkey</th><th>HotKV vs Dragonfly</th></tr></thead>
<tbody>{"".join(table)}</tbody></table></div>
<p>Operations per second, median of 2 runs. A ratio between two figures marked † is not exact, because either side could be higher.</p>

<h2>Setup</h2>
<ul>
<li>Servers: three <code>c8in.12xlarge</code> (48 vCPUs, 75 Gbit/s), one cluster placement group, AWS eu-south-2a, Ubuntu 24.04, kernel 7.0.0-1014-aws, every server process pinned to CPUs 0 to 39.</li>
<li>Load generators: one <code>c8in.48xlarge</code> (16 <code>memtier_benchmark</code> processes of 12 threads) and one <code>c8in.12xlarge</code> (4 processes of 12 threads), started together, results added up.</li>
<li>Workload: 5,000,000 keys, 256-byte values, pipeline depth 100, cluster mode, 15 seconds per run, 2 runs per command, the same dataset loaded again before every run.</li>
<li>Layout: HotKV and Dragonfly one process per server with 40 threads. Redis and Valkey 40 single-thread processes per server (120 primaries). Persistence off.</li>
<li>Versions: Redis 8.10.3, Valkey 9.1.3, Dragonfly 2.0.2 (built from source), HotKV 0.3.0 plus a change that adds the <code>pipeline-prefetch</code> setting, run with <code>pipeline-prefetch yes</code>. Redis and Valkey ran with their own batch prefetching at its default.</li>
<li>Host tuning on all five machines: <code>harness/tune_server.sh</code> and <code>scripts/tune_network.sh</code>.</li>
</ul>

<h2>Reading the results</h2>
<ul>
<li>The main load generator ran above {CLIENT_BOUND_PCT} percent CPU on GET, SETNX and INCR with HotKV, and on GET, SET, SETNX, INCR, SADD, HSET and APPEND with Redis and Valkey. Those figures are lower bounds. Redis and Valkey need 120 processes, which costs the load generators more per operation.</li>
<li>HotKV was behind Redis and Valkey on APPEND. We have not found the cause. APPEND grows the dataset by about 10 GB per second across the cluster, so the run is also a test of memory allocation. A 30 second APPEND run ran the servers out of memory.</li>
<li>Throughput only. Latency, persistence, replication and failover were not measured. Results apply to these versions, configurations and this workload.</li>
<li>Redis, Valkey and Dragonfly are trademarks of their respective owners, named only to identify the software measured. No sponsorship, endorsement or affiliation is implied.</li>
</ul>

<h2>Every run</h2>
<div class="card scroll"><table><thead><tr><th>Server</th><th>Command</th><th>Run</th><th>Ops/s</th><th>Hit ratio</th><th>Load gen 1 CPU %</th><th>Load gen 2 CPU %</th><th>Server CPU % (3 hosts)</th></tr></thead>
<tbody>{"".join(runs)}</tbody></table></div>
<p>Raw output of every run is in <code>data/</code>. The commands are in <code>scripts/run.sh</code>.</p>
</main></body></html>
"""
(ROOT / "RESULTS.html").write_text(page, encoding="utf-8")
print("wrote", ROOT / "RESULTS.html")
